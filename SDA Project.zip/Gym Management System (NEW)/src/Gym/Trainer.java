/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gym;

import Gym_classes.Person;
import Gym_classes.Trainer_c;
import javax.swing.table.TableModel;

/**
 *
 * @author jawadkhan
 */
public class Trainer extends javax.swing.JFrame {

    /**
     * Creates new form Add_Staff
     */
    public Trainer() {
        initComponents();
        setExtendedState(MAXIMIZED_BOTH);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Name_lbl = new javax.swing.JLabel();
        Age_lbl = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        name_txt = new javax.swing.JTextField();
        salary_txt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        Gender_lbl = new javax.swing.JLabel();
        Gender_combo = new javax.swing.JComboBox<>();
        timing_txt = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Search_btn = new javax.swing.JButton();
        Show_btn = new javax.swing.JButton();
        Select_cmb = new javax.swing.JComboBox<>();
        Search_txt = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        NIC_txt = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        ID_txt = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        mob_txt = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        Address_txt = new javax.swing.JTextField();
        Del_btn = new javax.swing.JButton();
        Update_btn = new javax.swing.JButton();
        Age_cmbo = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        Name_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Name_lbl.setForeground(new java.awt.Color(255, 255, 255));
        Name_lbl.setText("Name");
        getContentPane().add(Name_lbl);
        Name_lbl.setBounds(80, 180, 194, 30);

        Age_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Age_lbl.setForeground(new java.awt.Color(255, 255, 255));
        Age_lbl.setText("Age");
        getContentPane().add(Age_lbl);
        Age_lbl.setBounds(80, 260, 92, 17);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Salary");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(80, 440, 194, 17);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Timings");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(80, 480, 80, 17);

        name_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name_txtActionPerformed(evt);
            }
        });
        getContentPane().add(name_txt);
        name_txt.setBounds(350, 180, 183, 20);

        salary_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salary_txtActionPerformed(evt);
            }
        });
        getContentPane().add(salary_txt);
        salary_txt.setBounds(350, 440, 183, 20);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("TRAINER");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(440, 20, 164, 29);

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Add Staff");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(380, 530, 106, 25);

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Reset");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(520, 530, 88, 25);

        Gender_lbl.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Gender_lbl.setForeground(new java.awt.Color(255, 255, 255));
        Gender_lbl.setText("Gender");
        getContentPane().add(Gender_lbl);
        Gender_lbl.setBounds(80, 340, 92, 17);

        Gender_combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        getContentPane().add(Gender_combo);
        Gender_combo.setBounds(350, 340, 183, 23);

        timing_txt.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "6:00 am - 11:00 am", "5:00 pm - 10:00 pm" }));
        timing_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timing_txtActionPerformed(evt);
            }
        });
        getContentPane().add(timing_txt);
        timing_txt.setBounds(350, 480, 183, 29);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Name", "NIC", "Age","Address","Gender","Mobile NO","Salary","Timing"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTable1MousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(570, 110, 452, 230);

        Search_btn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Search_btn.setText("Search");
        Search_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Search_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Search_btn);
        Search_btn.setBounds(370, 70, 94, 25);

        Show_btn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Show_btn.setText("Show All Data");
        Show_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Show_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Show_btn);
        Show_btn.setBounds(640, 530, 127, 25);

        Select_cmb.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Select_cmb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Name", "NIC", "Age", "Gender", "Salary", "Timing" }));
        getContentPane().add(Select_cmb);
        Select_cmb.setBounds(80, 70, 94, 23);
        getContentPane().add(Search_txt);
        Search_txt.setBounds(210, 70, 118, 20);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("NIC");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(80, 220, 194, 30);

        NIC_txt.setText(" ");
        NIC_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NIC_txtActionPerformed(evt);
            }
        });
        getContentPane().add(NIC_txt);
        NIC_txt.setBounds(350, 220, 183, 20);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(80, 140, 194, 20);

        ID_txt.setEditable(false);
        ID_txt.setText(" ");
        getContentPane().add(ID_txt);
        ID_txt.setBounds(350, 140, 183, 20);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Mobile No");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(80, 390, 100, 20);

        mob_txt.setText(" ");
        getContentPane().add(mob_txt);
        mob_txt.setBounds(350, 390, 183, 20);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Address");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(80, 300, 92, 17);

        Address_txt.setText(" ");
        Address_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Address_txtActionPerformed(evt);
            }
        });
        getContentPane().add(Address_txt);
        Address_txt.setBounds(350, 300, 183, 20);

        Del_btn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Del_btn.setText("Delete");
        Del_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Del_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Del_btn);
        Del_btn.setBounds(250, 530, 92, 25);

        Update_btn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        Update_btn.setText("Update");
        Update_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Update_btnActionPerformed(evt);
            }
        });
        getContentPane().add(Update_btn);
        Update_btn.setBounds(120, 530, 106, 25);

        Age_cmbo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", " " }));
        getContentPane().add(Age_cmbo);
        Age_cmbo.setBounds(350, 250, 183, 25);

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setText("BACK");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(21, 0, 65, 23);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Gym/bg3.jpg"))); // NOI18N
        getContentPane().add(jLabel7);
        jLabel7.setBounds(4, -6, 1050, 600);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(890, 440, 166, 96);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
         

         String gender=""+Gender_combo.getSelectedItem();
         String time=""+timing_txt.getSelectedItem();
         String age=""+Age_cmbo.getSelectedItem();
        
         Trainer_c t=new Trainer_c(name_txt.getText(),NIC_txt.getText(),age,Address_txt.getText(),gender,mob_txt.getText(),salary_txt.getText(),time);
         t.add();
 
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Show_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Show_btnActionPerformed
        // TODO add your handling code here:
        Trainer_c t=new Trainer_c();
        t.showDetail(jTable1);
    }//GEN-LAST:event_Show_btnActionPerformed

    private void NIC_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NIC_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NIC_txtActionPerformed

    private void timing_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timing_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_timing_txtActionPerformed

    private void name_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_name_txtActionPerformed

    private void Address_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Address_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Address_txtActionPerformed

    private void Update_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Update_btnActionPerformed
        // TODO add your handling code here:
        String age=""+Age_cmbo.getSelectedItem();
        String gender=""+Gender_combo.getSelectedItem();
        String time=""+timing_txt.getSelectedItem();
        Trainer_c trnr=new Trainer_c();
        trnr.update(ID_txt.getText(),name_txt.getText(),NIC_txt.getText(),age,Address_txt.getText(), gender,mob_txt.getText(),salary_txt.getText(), time);
    }//GEN-LAST:event_Update_btnActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        ID_txt.setText("");
        name_txt.setText("");
        NIC_txt.setText("");
        mob_txt.setText("");
        Address_txt.setText("");
        salary_txt.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void Del_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Del_btnActionPerformed
        // TODO add your handling code here:
        Trainer_c trnr=new Trainer_c();
        trnr.del(ID_txt.getText());
    }//GEN-LAST:event_Del_btnActionPerformed

    private void Search_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Search_btnActionPerformed
        // TODO add your handling code here:
        String select=""+Select_cmb.getSelectedItem();
        Trainer_c trnr=new Trainer_c();
        trnr.search(jTable1, Search_txt.getText(), select);
    }//GEN-LAST:event_Search_btnActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        this.hide();
        HomePage hp=new HomePage();
        hp.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MousePressed
        // TODO add your handling code here:
        int i=jTable1.getSelectedRow();
        TableModel model=jTable1.getModel();
        ID_txt.setText(model.getValueAt(i,0).toString());
        name_txt.setText(model.getValueAt(i,1).toString());
        NIC_txt.setText(model.getValueAt(i,2).toString());
        Age_cmbo.setActionCommand(model.getValueAt(i,3).toString());
        Address_txt.setText(model.getValueAt(i,4).toString());
        Gender_combo.setActionCommand(model.getValueAt(i,5).toString());
        mob_txt.setText(model.getValueAt(i,6).toString());
        salary_txt.setText(model.getValueAt(i,7).toString());
        timing_txt.setActionCommand(model.getValueAt(i,8).toString());
    }//GEN-LAST:event_jTable1MousePressed

    private void salary_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salary_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salary_txtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Trainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Trainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Trainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Trainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Trainer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Address_txt;
    private javax.swing.JComboBox<String> Age_cmbo;
    private javax.swing.JLabel Age_lbl;
    private javax.swing.JButton Del_btn;
    private javax.swing.JComboBox<String> Gender_combo;
    private javax.swing.JLabel Gender_lbl;
    private javax.swing.JTextField ID_txt;
    private javax.swing.JTextField NIC_txt;
    private javax.swing.JLabel Name_lbl;
    private javax.swing.JButton Search_btn;
    private javax.swing.JTextField Search_txt;
    private javax.swing.JComboBox<String> Select_cmb;
    private javax.swing.JButton Show_btn;
    private javax.swing.JButton Update_btn;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField mob_txt;
    private javax.swing.JTextField name_txt;
    private javax.swing.JTextField salary_txt;
    private javax.swing.JComboBox<String> timing_txt;
    // End of variables declaration//GEN-END:variables
}
