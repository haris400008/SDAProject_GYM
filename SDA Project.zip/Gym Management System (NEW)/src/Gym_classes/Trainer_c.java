package Gym_classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class Trainer_c extends Person {

    Connection2DB conn = new Connection2DB();
    Connection con = conn.setConnection();

    private String Salary;

    public Trainer_c() {
        
    }

    public Trainer_c( String name, String NIC, String Age, String Address, String Gender, String mobile_num, String Salary, String time) {
        super( name, NIC, Age, Address, Gender, mobile_num, time);
        this.Salary = Salary;

    }

    public String getSalary() {
        return Salary;
    }

    // ADD METHOD 
    public void add() {

        PreparedStatement pst = null;
        try {

            String sql = "Insert into TrainerTable(Name,NIC,Age,Address,Gender,Mobileno,Salary,Timing) values (?,?,?,?,?,?,?,?)";
            pst = con.prepareStatement(sql);

            
            pst.setString(1, getName());
            pst.setString(2, getNIC());
            pst.setString(3, getAge());
            pst.setString(4, getAddress());
            pst.setString(5, getGender());
            pst.setString(6, getMobile_num());
            pst.setString(7, getSalary());
            pst.setString(8, getTime());
            pst.execute();

            JOptionPane.showMessageDialog(null, "saved");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //DELETE METHOD

    public boolean del(String id) {
        boolean del = false;
        try {
            String sql = "delete from TrainerTable where ID=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, id);
            pst.execute();
            JOptionPane.showMessageDialog(null, "DLETED");
            del = true;
        } catch (Exception e) {
        }
        return del;
    }
    // SEARCH METHOD

    public boolean search(JTable table, String search, String select) {
        boolean found = false;
        ResultSet rs = null;
        try {
            PreparedStatement pst = null;
            String sql = "select * from TrainerTable where " + select + "=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, search);
            rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
            found = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return found;
    }

    //UPDATE METHOD
    public boolean update(String id, String name, String nic, String age, String address, String gender, String mobno, String Salary, String timing) {
        boolean update = false;
        try {
            String sql = "update TrainerTable set Name='" + name + "',NIC='" + nic + "',Age='" + age + "',Address='" + address + "',Gender='" + gender + "',MobileNo='" + mobno + "',Salary='" + Salary + "',Timing='" + timing + "' where id='" + id + "'";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            update = true;
            JOptionPane.showMessageDialog(null, "Updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return update;
    }

    public void showDetail(JTable table) {

        try {
            String sql = "select * from TrainerTable ";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
