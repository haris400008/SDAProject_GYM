package Gym_classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class Connection2DB {
    
    //Settingup Connection
    public Connection setConnection(){
        String dataSourceName="database/Database2.accdb";
        String dir = System.getProperty("user.dir");    //project directory
        String url = "jdbc:ucanaccess://"+dir+"/" + dataSourceName;
        
        Connection con=null;
        try {
              con = DriverManager.getConnection(url);
            }
        catch(Exception sqlEx){
                    System.out.println(sqlEx);
        }
        return con;
    }
    public boolean matchPassword(String user, String pass){
        boolean successful =false;
        try {
             Connection con=setConnection();
            Statement st = con.createStatement();
            String sql = "select * from Login_Table where Username = '"+user+"'";
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
              String userName = rs.getString("Username");
              String password = rs.getString("Password");
              if(user.equals(userName) && pass.equals(password))
                  successful = true;
              else
                  successful = false;
            }
            con.close();
        }
        catch(Exception sqlEx){
                    System.out.println(sqlEx);
        }     
        return successful;
    }
     
     
     // SIGNUP
     public void Signup(String username,String pass) {

        PreparedStatement pst = null;
        try {
            Connection con=setConnection();
            String sql = "Insert into Login_Table(Username,Password) values(?,?)";
            pst = con.prepareStatement(sql);
            pst.setString(1,username);
            pst.setString(2, pass);
            pst.execute();

            JOptionPane.showMessageDialog(null, "saved");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
     }
   
}