package Gym_classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;


public class Customer_c extends Person {
    //Fields Declaration

    Connection2DB conn = new Connection2DB();
    Connection con = conn.setConnection();

    private String fees;
    private String trainer;
    private String MemberShip;
    private String MemberShipExp;

//Constructor to initialize fields

    public Customer_c(String fees, String trainer, String name, String NIC, String Age, String Address, String Gender, String mobile_num, String time,String jdate,String expdate) {
        super( name, NIC, Age, Address, Gender, mobile_num, time);
        this.fees = fees;
        this.trainer = trainer;
        this.MemberShip = jdate;
        this.MemberShipExp = expdate;
    }
    

    public Customer_c() {
        
    }

    //Getters for attributes
    public String getFees() {
        return fees;
    }

    public String getTrainer() {
        return trainer;
    }

    public String getMemberShip() {
        return MemberShip;
    }

    public String getMemberShipExp() {
        return MemberShipExp;
    }
    
    // ADD METHOD 
    public void add() {

        PreparedStatement pst = null;
        try {

            String sql = "Insert into CustomerTable(Name,NIC,Age,Address,Gender,MobileNo,Fees,Trainer,Timing,MemberShip_Date,MemberShip_Exp) values (?,?,?,?,?,?,?,?,?,?,?)";
            pst = con.prepareStatement(sql);
            pst.setString(1, getName());
            pst.setString(2, getNIC());
            pst.setString(3, getAge());
            pst.setString(4, getAddress());
            pst.setString(5, getGender());
            pst.setString(6, getMobile_num());
            pst.setString(7, getFees());
            pst.setString(8, getTrainer());
            pst.setString(9, getTime());
            pst.setString(10,getMemberShip());
            pst.setString(11, getMemberShipExp());
            pst.execute();

            JOptionPane.showMessageDialog(null, "saved");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    //DELETE METHOD

    public boolean del(String id) {
        boolean del = false;
        try {
            String sql = "delete from CustomerTable where ID=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, id);
            pst.execute();
            JOptionPane.showMessageDialog(null, "DLETED");
            del = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return del;
    }
    // SEARCH METHOD

    public boolean search(JTable table, String search, String select) {
        boolean found = false;
        ResultSet rs = null;
        try {
            PreparedStatement pst = null;
            String sql = "select * from CustomerTable where " + select + "=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, search);
            rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));// nahi pata mere khayal may table ko values show kra rha hai
            found = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return found;
    }

    //UPDATE METHOD
    public boolean update(String id, String name, String nic, String age, String address, String gender, String mobno, String fees, String timing, String trainer) {
        boolean update = false;
        try {
            String sql = "update CustomerTable set Name='" + name + "',NIC='" + nic + "',Age='" + age + "',Address='" + address + "',Gender='" + gender + "',MobileNo='" + mobno + "',Fees='" + fees + "',Timing='" + timing + "',Trainer='" + trainer + "' where id='" + id + "'";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            update = true;
            JOptionPane.showMessageDialog(null, "Updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return update;
    }

    //SHOW METHOD
    public void showDetail(JTable table) {

        try {
            String sql = "select * from CustomerTable ";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public String trainer(){
        String name=null;
        try {
            String sql="select Name from TrainerTable ";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
           while(rs.next()){
               name=rs.getString("Name");
           }
        } catch (Exception e) {
         JOptionPane.showMessageDialog(null,e);   
        }
        return name;
    }
    
    
}