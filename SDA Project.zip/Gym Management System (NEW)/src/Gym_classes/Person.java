package Gym_classes;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public abstract class Person {
    private String name,NIC,Age,Address,Gender,mobile_num,time;
    

    public Person(String name, String NIC, String Age, String Address, String Gender, String mobile_num, String time) {
        
        this.name = name;
        this.NIC = NIC;
        this.Age = Age;
        this.Address = Address;
        this.Gender = Gender;
        this.mobile_num = mobile_num;
        this.time=time;
    }

    public Person() {
        
    }
   

    public String getName() {
        return name;
    }

    public String getNIC() {
        return NIC;
    }

    public String getAge() {
        return Age;
    }

    public String getAddress() {
        return Address;
    }

    public String getGender() {
        return Gender;
    }

    public String getMobile_num() {
        return mobile_num;
    }

    public String getTime() {
        return time;
    }
    
    
    public abstract void add();
    public abstract boolean search(JTable table,String select,String name);
    public abstract boolean del(String id);
}