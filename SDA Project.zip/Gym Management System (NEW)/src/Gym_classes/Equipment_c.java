package Gym_classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import net.proteanit.sql.DbUtils;

public class Equipment_c {

    Connection2DB conn = new Connection2DB();
    Connection con = conn.setConnection();

    private String ID;
    private String name;
    private String Quantity;
    private String perprice;
    private String totalprice;
    private String date;

    public Equipment_c() {
    }

    public Equipment_c( String name, String Quantity, String perprice, String totalprice, String date) {
        this.name = name;
        this.Quantity = Quantity;
        this.perprice = perprice;
        this.totalprice = totalprice;
        this.date = date;
    }

    public String getID() {
        return ID;
    }

    public String getName() {
        return name;
    }

    public String getQuantity() {
        return Quantity;
    }

    public String getPerprice() {
        return perprice;
    }

    public String getTotalprice() {
        return totalprice;
    }

    public String getDate() {
        return date;
    }

//ADD METHOD
    public void add() {

        PreparedStatement pst = null;
        try {

            String sql = "Insert into EquipmentTable(Name,Quantity,PricePerQuantity,TotalPrice,Date) values (?,?,?,?,?)";
            pst = con.prepareStatement(sql);

            
            pst.setString(1, getName());
            pst.setString(2, getQuantity());
            pst.setString(3, getPerprice());
            pst.setString(4, getTotalprice());
            pst.setString(5, getDate());
            pst.execute();

            JOptionPane.showMessageDialog(null, "saved");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    //DELETE METHOD
    public boolean del(String id) {
        boolean del = false;
        PreparedStatement pst = null;

        
        try {
            String sql = "delete from EquipmentTable where ID=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, id);
            pst.execute();
            JOptionPane.showMessageDialog(null, "DLETED");
            del = true;
        } catch (Exception e) {
        }
        return del;
    }

    // SEARCH METHOD
    public boolean search(JTable table, String search, String select) {
        boolean found = false;
        ResultSet rs = null;
        try {
            PreparedStatement pst = null;
            String sql = "select * from EquipmentTable where " + select + "=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, search);
            rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));// nahi pata mere khayal may table ko values show kra rha hai
            found = true;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return found;
    }

    //UPDATE METHOD
    public boolean update(String id, String name, String quantity, String PriceperQuantity, String totalPrice, String date) {
        boolean update = false;
        try {
            String sql = "update EquipmentTable set Name='" + name + "',Quantity='" + quantity + "',PricePerQuantity='" + PriceperQuantity + "',TotalPrice='" + totalPrice + "',Date='" + date + "' where id='" + id + "'";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            update = true;
            JOptionPane.showMessageDialog(null, "Updated");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return update;
    }

    //SHOWDETAILS METHOD
    public void showDetail(JTable table) {

        try {
            String sql = "select * from EquipmentTable ";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    //Calculation method
    public String cal(int quantity, int PerpriceQ) {

        int result = quantity * PerpriceQ;
        String Result = Integer.toString(result);
        return Result;
    }

}
