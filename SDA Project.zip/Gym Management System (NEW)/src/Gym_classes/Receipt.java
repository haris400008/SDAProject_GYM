/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gym_classes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
/**
 *
 * @author com plus
 */
public class Receipt {
 JTextField id;
 JTextField name;
 JTextField fees;
 JTextField trainer;
 
    Connection2DB conn = new Connection2DB();
    Connection con = conn.setConnection();
    public Receipt(JTextField id, JTextField name, JTextField fees, JTextField trainer) {
        this.id = id;
        this.name = name;
        this.fees =fees;
        this.trainer = trainer;
    }
 
 
 public void bill(String ID)
    {  
        ResultSet rs;
          try{  PreparedStatement pst =null;
        String sql="select [ID],[Name],[Fees],[Trainer] from CustomerTable where ID='"+ID+"'";
        pst=con.prepareStatement(sql);
        rs=pst.executeQuery();
        while(rs.next()){
            String add1=rs.getString("Name");
            name.setText(add1);
            String add2=rs.getString("Fees");
            fees.setText(add2);
            String add3=rs.getString("Trainer");
            trainer.setText(add3);
        }
          }
          catch (Exception e){
              JOptionPane.showMessageDialog(null, e);
          }
         
          
    }
}
